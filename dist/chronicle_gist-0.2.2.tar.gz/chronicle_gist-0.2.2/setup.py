from setuptools import setup

setup(version="0.2.2")
